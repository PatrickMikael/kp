import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tambahpesanan',
  templateUrl: './tambahpesanan.page.html',
  styleUrls: ['./tambahpesanan.page.scss'],
})
export class TambahpesananPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
